#include <string>
using namespace std;

/**
   Return a string that mixes the characters in strings a and b.
   If one string is longer than the other, append the suffix.
   For example, mixing "San" and "Francisco" yields "SFarnancisco".
*/
string mix(string a, string b)
{
   int length = a.length()+b.length();
    char str3[100];
    if(a.length()!=b.length())
    {
      if(a.length()<b.length())
      {
           int i=0;
           for(int j=0;j<length;j++)
           {
               if(i < a.length())
               {
                   str3[j] = a[i];
                   j++;
                   str3[j] = b[i];
                   i++;
               }
               else if(i < b.length())
               {
                   str3[j] = b[i];
                   i++;
               }
           }
        }
        else if(a.length() > b.length())
        {
           int i=0;
           for(int j=0;j<length;j++)
           {
               if(i < b.length())
               {
                   str3[j] = a[i];
                   j++;
                   str3[j] = b[i];
                   i++;
               }
               else if(i < a.length())
               {
                   str3[j] = a[i];
                   i++;
               }
           }
        }
     }
    else if(a.length() == b.length())
        {
           int i=0;
           for(int j=0;j<length;j++)
           {
               if(i < a.length())
               {
                   str3[j] = a[i];
                   j++;
                   str3[j] = b[i];
                   i++;
               }
               else if(i < b.length())
               {
                   str3[j] = a[i];
                   i++;
               }
           }
           str3[length] = '\0';
        }
     return str3;
   
}
